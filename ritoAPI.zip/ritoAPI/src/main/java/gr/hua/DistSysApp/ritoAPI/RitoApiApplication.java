package gr.hua.DistSysApp.ritoAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RitoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RitoApiApplication.class, args);
	}

}
